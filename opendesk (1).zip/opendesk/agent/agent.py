"""OpenDesk - agente do PC (Windows). Gera ID + senha, pede sua aprovação e libera tela e controle."""
import asyncio, io, json, os, re, subprocess, time, webbrowser

import ctypes
try:
    ctypes.windll.user32.SetProcessDPIAware()  # coordenadas reais em telas com escala
except Exception:
    pass

import mss
import pyautogui
import websockets
from PIL import Image

SERVER = os.environ.get("OPENDESK_SERVER", "ws://localhost:3000/agent")
FPS = int(os.environ.get("OPENDESK_FPS", "10"))
MAX_WIDTH = int(os.environ.get("OPENDESK_MAX_WIDTH", "1280"))
QUALITY = int(os.environ.get("OPENDESK_QUALITY", "55"))

pyautogui.FAILSAFE = True  # mouse no canto superior esquerdo = encerra a sessão remota
pyautogui.PAUSE = 0

KEYS = {
    "ArrowUp": "up", "ArrowDown": "down", "ArrowLeft": "left", "ArrowRight": "right",
    "Enter": "enter", "Escape": "esc", "Backspace": "backspace", "Tab": "tab", " ": "space",
    "Shift": "shift", "Control": "ctrl", "Alt": "alt", "Delete": "delete", "Home": "home",
    "End": "end", "PageUp": "pageup", "PageDown": "pagedown", "Meta": "win", "CapsLock": "capslock",
    "Insert": "insert",
}

def map_key(k):
    if k in KEYS:
        name = KEYS[k]
    elif len(k) == 1:
        name = k.lower()
    elif re.fullmatch(r"F\d{1,2}", k):
        name = k.lower()
    else:
        return None
    return name if name in pyautogui.KEYBOARD_KEYS else None

# Apenas apps comuns de um PC físico (lista fixa: nada além disso pode ser aberto remotamente).
APPS = {
    "explorer": lambda: subprocess.Popen(["explorer.exe"]),
    "terminal": lambda: subprocess.Popen(["cmd.exe"], creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0)),
    "browser": lambda: webbrowser.open("about:blank"),
    "settings": lambda: os.startfile("ms-settings:"),
    "calc": lambda: subprocess.Popen(["calc.exe"]),
    "notepad": lambda: subprocess.Popen(["notepad.exe"]),
    "start": lambda: pyautogui.press("win"),
}

def monitor():
    with mss.mss() as sct:
        return dict(sct.monitors[1])

def grab(mon):
    with mss.mss() as sct:
        shot = sct.grab(mon)
    im = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    if im.width > MAX_WIDTH:
        im = im.resize((MAX_WIDTH, int(im.height * MAX_WIDTH / im.width)))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=QUALITY)
    return buf.getvalue()

def clamp(v):
    return max(0.0, min(1.0, float(v)))

def handle_input(m, mon, held):
    t = m.get("t")
    if t == "move":
        pyautogui.moveTo(mon["left"] + int(clamp(m["x"]) * (mon["width"] - 1)), mon["top"] + int(clamp(m["y"]) * (mon["height"] - 1)))
    elif t in ("down", "up"):
        btn = {0: "left", 1: "middle", 2: "right"}.get(m.get("b"), "left")
        (pyautogui.mouseDown if t == "down" else pyautogui.mouseUp)(button=btn)
    elif t == "wheel":
        pyautogui.scroll(int(-float(m.get("dy", 0)) * 1.2))
    elif t == "key":
        name = map_key(str(m.get("k", "")))
        if name:
            if m.get("down"):
                pyautogui.keyDown(name); held.add(name)
            else:
                pyautogui.keyUp(name); held.discard(name)
    elif t == "launch":
        fn = APPS.get(str(m.get("app")))
        if fn:
            fn()

def ask(ip):
    # OPENDESK_APPROVAL=dialog: janela do Windows (necessário quando não há console, ex.: runner do GitHub)
    if os.environ.get("OPENDESK_APPROVAL") == "dialog":
        try:
            msg = f"Pedido de conexão de {ip}.\n\nPermitir acesso e controle deste PC?"
            # MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2 (padrão: Não) | MB_TOPMOST; 6 = Sim
            return ctypes.windll.user32.MessageBoxW(0, msg, "OpenDesk", 0x4 | 0x20 | 0x100 | 0x40000) == 6
        except Exception:
            return False
    print(f"\n>>> Pedido de conexão de {ip}. Permitir acesso e controle deste PC? [s/N] ", end="", flush=True)
    return input().strip().lower() in ("s", "sim", "y", "yes")

async def run(url):
    loop = asyncio.get_running_loop()
    async with websockets.connect(url, max_size=2**20, ping_interval=20) as ws:
        sess = None  # {"task": Task, "held": set, "mon": dict}

        def stop_session():
            nonlocal sess
            if not sess:
                return
            sess["task"].cancel()
            for k in list(sess["held"]):
                try: pyautogui.keyUp(k)
                except Exception: pass
            sess = None

        async def stream(mon):
            await ws.send(json.dumps({"type": "info", "w": mon["width"], "h": mon["height"]}))
            delay = 1 / max(1, FPS)
            while True:
                t0 = time.time()
                await ws.send(await loop.run_in_executor(None, grab, mon))
                await asyncio.sleep(max(0, delay - (time.time() - t0)))

        async def on_request(ip):
            nonlocal sess
            ok = await loop.run_in_executor(None, ask, ip)
            await ws.send(json.dumps({"type": "decision", "accept": ok}))
            if ok:
                mon = monitor()
                sess = {"task": asyncio.create_task(stream(mon)), "held": set(), "mon": mon}
                print("Sessão ativa. Para encerrar: mova o mouse para o canto superior esquerdo ou feche este programa.")

        async for raw in ws:
            if isinstance(raw, bytes):
                continue
            try:
                m = json.loads(raw)
            except ValueError:
                continue
            kind = m.get("type")
            if kind == "credentials":
                print("\n" + "=" * 42 + f"\n  ID:     {m['id'][:3]} {m['id'][3:6]} {m['id'][6:]}\n  SENHA:  {m['password']}\n" + "=" * 42)
                print("Informe o ID e a senha somente a quem você autoriza.")
            elif kind == "request":
                asyncio.create_task(on_request(m.get("from", "desconhecido")))
            elif kind == "ended":
                stop_session()
                print("Sessão encerrada. Uma nova senha foi gerada.")
            elif sess and "t" in m:
                try:
                    handle_input(m, sess["mon"], sess["held"])
                except pyautogui.FailSafeException:
                    await ws.send(json.dumps({"type": "leave"}))
                    stop_session()
                except Exception as e:
                    print("Entrada ignorada:", e)

def main():
    while True:
        try:
            asyncio.run(run(SERVER))
        except KeyboardInterrupt:
            print("\nAgente encerrado.")
            break
        except Exception as e:
            print(f"Sem conexão com o servidor ({e}). Tentando de novo em 3s...")
            time.sleep(3)

if __name__ == "__main__":
    main()
