# OpenDesk

Acesso remoto simples, no estilo "ID + senha": o PC gera um **ID de 9 dígitos** e uma **senha de 8 caracteres**; quem quiser acessar abre o site, digita os dois, o dono do PC **aprova** e a tela aparece no navegador, com mouse, teclado e controle (joystick) na tela.

Este projeto é independente: **não usa a rede nem o protocolo do AnyDesk** (que é proprietário). Se você precisa do AnyDesk de verdade, instale o aplicativo oficial. Uma alternativa de código aberto e auto-hospedável é o RustDesk.

## Como funciona

```
PC (Windows)  <--WebSocket-->  Servidor Node.js  <--WebSocket-->  Navegador
agent/agent.py                 server.js                          public/index.html
```

- **Agente** (`agent/agent.py`): captura a tela, executa mouse/teclado e mostra o ID e a senha no console.
- **Servidor** (`server.js`): gera ID e senha, valida o acesso e repassa tela e comandos.
- **Visualizador** (`public/index.html`): tela de conexão, barra de tarefas com apps de PC físico (Iniciar, Explorador de Arquivos, Prompt de Comando, Navegador, Configurações, Calculadora, Bloco de Notas) e controle na tela.

Com a tela do PC aberta, você usa jogos, aplicativos e terminal do próprio Windows, como se estivesse na frente dele.

## Requisitos

- Servidor: Node.js 18+
- PC a ser acessado: Windows 10/11 e Python 3.9+

## Instalação

Servidor:

```bash
npm install
npm start          # http://localhost:3000
```

Agente (no PC que será acessado):

```bash
cd agent
pip install -r requirements.txt
set OPENDESK_SERVER=ws://SEU_SERVIDOR:3000/agent     # no PowerShell: $env:OPENDESK_SERVER="ws://..."
python agent.py
```

O console mostra o ID e a senha. Em outro dispositivo, abra `http://SEU_SERVIDOR:3000`, digite os dois e peça para quem está no PC digitar `s` para aceitar.

## Segurança

- Senha gerada com gerador criptográfico, **de uso único**: após cada tentativa válida ela é descartada e uma nova é gerada.
- O dono do PC **precisa aprovar cada conexão** (não há modo automático). O pedido expira em 30 segundos.
- Bloqueio por IP após 5 tentativas erradas (1 minuto). A mensagem de erro é a mesma para ID inexistente e senha errada.
- Encerramento de emergência: mova o mouse para o **canto superior esquerdo** da tela, ou feche o agente.
- Apps remotos: só os 7 da lista fixa em `APPS` (`agent.py`).
- **Em produção, use HTTPS/WSS** (por exemplo Caddy, nginx ou Cloudflare na frente) e defina `TRUST_PROXY=1` se estiver atrás de proxy. Sem TLS, a tela e a senha trafegam sem criptografia. Use o agente `wss://SEU_DOMINIO/agent`.
- Use apenas em computadores seus ou com autorização de quem os usa.

## Controle (joystick)

Os botões na tela e um controle físico (Gamepad API) são convertidos em teclas do PC. Edite o objeto `MAP` em `public/index.html` para cada jogo. Isso não cria um controle virtual no Windows; para isso seria preciso o driver ViGEmBus no agente.

## Limitações

- Sem áudio.
- Janelas de administrador (UAC), tela de login e Ctrl+Alt+Del não são controláveis.
- Caracteres com acento digitados no teclado remoto podem não ser enviados.
- A transmissão é por imagens JPEG (cerca de 10 FPS, ajustável com `OPENDESK_FPS`, `OPENDESK_QUALITY`, `OPENDESK_MAX_WIDTH`). É adequada para apps e jogos leves, não para jogos competitivos.
- Um visualizador por PC por vez.

## Publicar no GitHub

```bash
git init
git add .
git commit -m "OpenDesk"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/opendesk.git
git push -u origin main
```

Para hospedar o servidor, use um serviço que aceite WebSocket (Render, Railway, Fly.io ou uma VPS).

## Workflows do GitHub Actions

Em `.github/workflows/`:

- `ci.yml`: a cada push, verifica a sintaxe do servidor e do agente e sobe o servidor para testar `/health`. Roda sozinho, sem configuração.
- `agent.yml`: inicia o agente no **seu próprio PC Windows** por um runner self-hosted. Passos: em Settings > Actions > Runners, adicione um runner no seu PC e execute `run.cmd` com você logado (não como serviço, senão o Windows não deixa capturar a tela); depois, na aba Actions, rode "Iniciar agente no meu PC" informando o endereço do servidor. O ID e a senha aparecem no log do job, então use um **repositório privado**. A aprovação do acesso aparece como janela do Windows no PC.

Não use runners hospedados pelo GitHub (`windows-latest` etc.) como PC remoto: os Termos do GitHub Actions não permitem usar o Actions para isso, a conta pode ser suspensa, e o runner não tem GPU, some ao fim do job (limite de 6 horas) e não roda jogos de verdade.

## Licença

MIT
