// OpenDesk - servidor: gera ID + senha, valida o acesso e repassa tela/controle entre o PC (agente) e o visualizador web.
import express from "express";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const APPROVAL_TIMEOUT_MS = 30_000; // tempo para o dono do PC aprovar
const MAX_FAILS = 5;                // tentativas erradas antes do bloqueio
const LOCK_MS = 60_000;             // duração do bloqueio por IP

const app = express();
app.disable("x-powered-by");
app.use((_req, res, next) => {
  res.set({ "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer" });
  next();
});
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.send("ok"));

const server = createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 2 * 1024 * 1024 });

const agents = new Map(); // id -> { id, ws, state: idle|pending|active, viewer, salt, hash, timer }
const fails = new Map();  // ip -> { n, until }

const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // sem caracteres ambíguos (0/O, 1/I)
const genId = () => {
  let id;
  do { id = String(crypto.randomInt(100_000_000, 1_000_000_000)); } while (agents.has(id));
  return id;
};
const genPass = () => Array.from({ length: 8 }, () => ALPHA[crypto.randomInt(ALPHA.length)]).join("");
const hashPass = (p, salt) => crypto.scryptSync(String(p).toUpperCase(), salt, 32);
const send = (ws, o) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); };
const clientIp = (req) =>
  process.env.TRUST_PROXY ? (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress : req.socket.remoteAddress;

const isLocked = (ip) => (fails.get(ip)?.until || 0) > Date.now();
function addFail(ip) {
  const f = fails.get(ip) || { n: 0, until: 0 };
  f.n++;
  if (f.n >= MAX_FAILS) { f.until = Date.now() + LOCK_MS; f.n = 0; }
  fails.set(ip, f);
}

// Gera uma senha nova (de uso único) e envia ao agente.
function issue(a) {
  const pass = genPass();
  a.salt = crypto.randomBytes(16);
  a.hash = hashPass(pass, a.salt);
  send(a.ws, { type: "credentials", id: a.id, password: pass });
}

function endSession(a, reason) {
  const v = a.viewer;
  const was = a.state;
  clearTimeout(a.timer);
  a.viewer = null;
  a.state = "idle";
  if (v) { send(v, { type: reason === "denied" ? "denied" : "ended" }); v.close(); }
  if (was !== "idle" && a.ws.readyState === 1) { send(a.ws, { type: "ended" }); issue(a); }
}

server.on("upgrade", (req, socket, head) => {
  const p = new URL(req.url, "http://x").pathname;
  if (p !== "/agent" && p !== "/viewer") return socket.destroy();
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req, p));
});

wss.on("connection", (ws, req, role) => (role === "/agent" ? onAgent(ws) : onViewer(ws, req)));

function onAgent(ws) {
  const a = { id: genId(), ws, state: "idle", viewer: null, salt: null, hash: null, timer: null };
  agents.set(a.id, a);
  issue(a);

  ws.on("message", (data, isBinary) => {
    if (isBinary) { // quadro de tela -> visualizador
      if (a.state === "active" && a.viewer?.readyState === 1 && a.viewer.bufferedAmount < 2_000_000) a.viewer.send(data, { binary: true });
      return;
    }
    let m;
    try { m = JSON.parse(data.toString()); } catch { return; }
    if (m.type === "decision" && a.state === "pending") {
      if (m.accept === true) {
        clearTimeout(a.timer);
        a.state = "active";
        send(a.viewer, { type: "accepted" });
      } else endSession(a, "denied");
    } else if (m.type === "decision") send(ws, { type: "ended" }); // pedido já cancelado/expirado
    else if (m.type === "info" && a.state === "active") send(a.viewer, m);
    else if (m.type === "leave" && a.state !== "idle") endSession(a, "agent");
  });
  ws.on("close", () => {
    agents.delete(a.id);
    clearTimeout(a.timer);
    if (a.viewer) { send(a.viewer, { type: "ended" }); a.viewer.close(); }
  });
}

function onViewer(ws, req) {
  const ip = clientIp(req);
  let target = null;

  ws.on("message", (data, isBinary) => {
    if (isBinary || data.length > 1024) return;
    let m;
    try { m = JSON.parse(data.toString()); } catch { return; }

    if (!target) {
      if (m.type !== "connect") return;
      if (isLocked(ip)) { send(ws, { type: "error", message: "Muitas tentativas. Aguarde 1 minuto." }); return ws.close(); }
      const a = agents.get(String(m.id || "").replace(/\s/g, ""));
      let ok = false;
      if (a && a.state === "idle" && a.hash && typeof m.password === "string") {
        const h = hashPass(m.password, a.salt);
        ok = crypto.timingSafeEqual(h, a.hash);
      }
      if (!ok) { addFail(ip); send(ws, { type: "error", message: "ID ou senha inválidos, ou o PC está ocupado." }); return ws.close(); }

      target = a;
      a.state = "pending";
      a.viewer = ws;
      a.hash = null; // senha de uso único: não pode ser reutilizada
      send(a.ws, { type: "request", from: ip });
      send(ws, { type: "waiting" });
      a.timer = setTimeout(() => { if (a.state === "pending") endSession(a, "denied"); }, APPROVAL_TIMEOUT_MS);
      return;
    }

    if (target.state === "active" && target.viewer === ws && typeof m.t === "string") send(target.ws, m); // entrada (mouse/teclado/atalhos)
  });

  ws.on("close", () => { if (target && target.viewer === ws) endSession(target, "viewer"); });
}

setInterval(() => wss.clients.forEach((c) => c.readyState === 1 && c.ping()), 30_000);
server.listen(PORT, () => console.log(`OpenDesk rodando em http://localhost:${PORT}`));
